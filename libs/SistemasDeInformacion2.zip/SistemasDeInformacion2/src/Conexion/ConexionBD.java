package Conexion;
/**
 *
 * @author PC
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
public class ConexionBD {
    private Connection con; 
    
    public ConexionBD()throws ClassNotFoundException, SQLException{
        Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
        String connectionURL = "jdbc:sqlserver://JOSUE\\SQLEXPRESS:1433;databaseName=Websis;user=jodemvel;password=Js-170120;"; 
        con = DriverManager.getConnection(connectionURL);
    }
    
    public Connection conexion(){
        return con;
    }
    
    public static void main(String args[]) throws ClassNotFoundException, SQLException{
        ConexionBD bd = new ConexionBD();
    }
    
}